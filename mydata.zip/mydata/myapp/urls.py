from django.urls import path
from myapp import views
from myapp.views import plot_graph
from django.conf import settings
from django.conf.urls.static import static


app_name = 'myapp'

urlpatterns = [
    path('', views.index, name='index'),
    path('show', views.show, name='show'),
    path('form/', views.form, name='form'),
    path('form/<int:person_id>/', views.form, name='form'),
    path('delete/<int:person_id>/', views.delete, name='delete'),
    path('edit/<int:person_id>', views.edit, name='edit'),
    path('edit/<int:person_id>/form/', views.edit_form, name='edit_form'),
    
    path('plot_graph/', views.plot_graph, name='plot_graph'),  
    path('plot_graph/', views.plot_graph_form, name='plot_graph_form'),
    path('plot_graph/<int:target>/<int:amount>/', views.plot_graph, name='plot_graph'),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)