from contextlib import redirect_stdout
from email.charset import BASE64
import os
from wsgiref.util import request_uri
from django.conf import Settings
from django.shortcuts import redirect, render
from django.http import HttpResponse   #เพิ่มHttpResponseเข้ามาคือคำสั่งตอบกลับ
from myapp.models import Person
from django.contrib import messages
from django.shortcuts import redirect, render, get_object_or_404
from django import forms
from myapp.models import Person
from django.contrib.staticfiles.views import serve
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import random


class PersonForm(forms.ModelForm):
    class Meta:
        model = Person
        fields = "__all__"

# Create your views here.
def index(request):
    # โค้ดที่ต้องการ
    return render(request, "index.html")



def set(request):
    # โค้ดที่ต้องการ
    return render(request, "form.html")

def form(request, person_id=None):
    if request.method == "POST":
        #รับข้อมูล
        mo = request.POST.get("mo")
        yer = request.POST.get("yer")
        name = request.POST.get("name")
        target = request.POST.get("target")
        amount = request.POST.get("amount")
        
        
        #บันทึกข้อมูล
        person = Person.objects.create(
            mo=mo, 
            yer=yer,
            name=name,
            target=target,
            amount=amount
        )
        person.save()
        messages.success(request, "บันทึกข้อมูลเรียบร้อย")
        #เปลี่ยนเส้นทาง
        return redirect("/show")
    else:
        if person_id is not None:
            person = get_object_or_404(Person, id=person_id)
        else:
            person = None
        
        return render(request, "form.html", {"person": person})
    
    
    
def edit(request, person_id):
    if request.method == "POST":
        person = get_object_or_404(Person, id=person_id)
        person.mo = request.POST["mo"]
        person.yer = request.POST["yer"]
        person.name = request.POST["name"]
        person.target = request.POST["target"]
        person.amount = request.POST["amount"]
        person.save()
        messages.success(request, "อัพเดทเรียบร้อย")
        return redirect("/show")
    else:
        person = get_object_or_404(Person, id=person_id)
        return render(request, "edit.html", {"person": person})
        
    
def delete(request, person_id):
    person = Person.objects.get(id=person_id)
    person.delete()
    messages.success(request,"ลบข้อมูลเรียบร้อย")
    return redirect("/show")

def show(request):
    if request.method == "POST":
        search_term = request.POST.get("search")
        all_person = Person.objects.filter(mo=search_term)
    else:
        all_person = Person.objects.all()
    
    return render(request, "show.html", {"all_person": all_person})





def edit_form(request, person_id):
    if request.method == "POST":
        person = get_object_or_404(Person, id=person_id)
        # รับข้อมูลจากฟอร์มแก้ไข
        form_data = {
            "mo": request.POST["mo"],
            "yer": request.POST["yer"],
            "name": request.POST["name"],
            "target": request.POST["target"],
            "amount": request.POST["amount"],
        }
        # สร้างแบบฟอร์มด้วยข้อมูลที่รับมา
        form = PersonForm(form_data, instance=person)
        if form.is_valid():
            form.save()
            messages.success(request, "อัพเดทเรียบร้อย")
            return redirect("/show")
    else:
        person = get_object_or_404(Person, id=person_id)
        form = PersonForm(instance=person)
    return render(request, "edit_form.html", {"person": person, "form": form})
    
from django.shortcuts import render

from django.conf import settings

def plot_graph_form(request):
    return render(request, 'plot_graph.html')

def plot_graph(request, target, amount):
    import matplotlib.pyplot as plt

    # ข้อมูลสำหรับกราฟแท่ง
    labels = ['Target', 'Earned Amount']

    # สร้างข้อมูล values โดยใช้ข้อมูลจากพารามิเตอร์
    values = [target, amount]

    # สร้างกราฟแท่ง
    plt.bar(labels, values)

    # กำหนดชื่อแกน x และ y
    plt.xlabel('Categories')
    plt.ylabel('Values')

    # บันทึกภาพเป็นไฟล์รูปภาพ
    filename = f"graph_{random.randint(1, 100000)}.png"
    graph_path = os.path.join('myapp', 'static', 'images', filename)
    graph_full_path = os.path.join(settings.STATIC_ROOT, 'images', filename)
    plt.savefig(graph_full_path)

    # คืนเส้นทางของไฟล์รูปภาพเพื่อแสดงในเท็มเพลต
    context = {
        'graph_path': graph_path,
    }
    return render(request, 'plot_graph.html', context)





