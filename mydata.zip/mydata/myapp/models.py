from django.db import models

class Person(models.Model):
    mo = models.CharField(max_length=255)
    yer = models.IntegerField()
    name = models.CharField(max_length=255)  # กำหนดความยาวสูงสุดของข้อมูลให้เป็น 100
    target = models.CharField(max_length=100)
    amount = models.CharField(max_length=100)

    def __str__(self):
        return "วันที่สรุปสถิติ = " + str(self.mo) + "ปีที่สรุปสถิติ = " + str(self.yer) + ", ชื่อแผนก = " + self.name + ", Target = " + str(self.target) + ", Amount = " + str(self.amount)